"""Synthetic unit fixtures only. No real patent result or inference is fabricated."""
import sys,unittest,copy,tempfile,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
import common,schema,extract
from unittest.mock import patch
def fixture():
 title='Test device';abstract='The test device uses a 5 nm porous layer to reduce drift.'
 doc=dict(family_id='test:synthetic',title=title,abstract=abstract,raw_text=title+'\n\n'+abstract)
 doc['text_hash']=common.digest_bytes(doc['raw_text'].encode())
 def f(text):return dict(text=text,evidence_ids=['E1'] if text is not None else [])
 c=dict(technical_object=f('测试器件'),technical_problem=f(None),technical_mechanism=f('采用5 nm多孔层'),implementation=f('在器件中使用多孔层'),expected_effect=f('降低漂移'),applicable_conditions=f(None),materials=[],process_methods=[],structures=[f('多孔层')],parameters=[dict(name='layer thickness',kind='LENGTH',raw='5 nm',evidence_ids=['E1'])],evidence_spans=[dict(id='E1',field='abstract',quote=abstract)],evidence_level='EXPLICIT_MECHANISM',mechanism_type='STRUCTURE',ambiguity_notes='')
 return doc,dict(family_id=doc['family_id'],contributions=[c])

def to_wire(result):
 wire=dict(family_id=result["family_id"],contributions=[])
 for c in result["contributions"]:
  item={}
  for e in c["evidence_spans"]:
   support=[]
   for name in schema.CORE_FIELDS:
    if e["id"] in c[name]["evidence_ids"]:support.append(name)
   for name in schema.LIST_FIELDS+["parameters"]:
    if any(e["id"] in row["evidence_ids"] for row in c[name]):support.append(name)
   item.setdefault("evidence_spans",[]).append(dict(field=e["field"],quote=e["quote"],supports=support))
  for name in schema.CORE_FIELDS:item[name]=c[name]["text"]
  for name in schema.LIST_FIELDS:item[name]=[row["text"] for row in c[name]]
  item["parameters"]=[{k:v for k,v in row.items() if k!="evidence_ids"} for row in c["parameters"]]
  for name in ["mechanism_type","evidence_level","ambiguity_notes"]:item[name]=c[name]
  wire["contributions"].append(item)
 return wire

class EvidenceTests(unittest.TestCase):
 def test_valid_and_stable_id(self):
  d,r=fixture();a=schema.audit_extraction(copy.deepcopy(r),d);b=schema.audit_extraction(copy.deepcopy(r),d)
  self.assertEqual(a['contributions'][0]['contribution_id'],b['contributions'][0]['contribution_id'])
  e=a['contributions'][0]['evidence_spans'][0];self.assertEqual(d[e['field']][e['start']:e['end']],e['quote'])
 def mutate_reject(self,fn):
  d,r=fixture();fn(r)
  with self.assertRaises((ValueError,AssertionError)):schema.audit_extraction(r,d)
 def test_nonverbatim(self):self.mutate_reject(lambda r:r['contributions'][0]['evidence_spans'][0].update(quote='The test device uses a 5  nm porous layer.'))
 def test_wrong_field(self):self.mutate_reject(lambda r:r['contributions'][0]['evidence_spans'][0].update(field='title'))
 def test_hallucinated_number(self):self.mutate_reject(lambda r:r['contributions'][0]['technical_mechanism'].update(text='采用10 nm多孔层'))
 def test_parameter_paraphrase(self):self.mutate_reject(lambda r:r['contributions'][0]['parameters'][0].update(raw='5纳米'))
 def test_family_mismatch(self):self.mutate_reject(lambda r:r.update(family_id='test:wrong'))
 def test_unknown_evidence(self):self.mutate_reject(lambda r:r['contributions'][0]['technical_mechanism'].update(evidence_ids=['E99']))
 def test_null_supported(self):self.mutate_reject(lambda r:r['contributions'][0]['technical_problem'].update(evidence_ids=['E1']))
 def test_missing_mechanism(self):self.mutate_reject(lambda r:r['contributions'][0]['technical_mechanism'].update(text=None,evidence_ids=[]))
 def test_duplicate_contribution(self):self.mutate_reject(lambda r:r['contributions'].append(copy.deepcopy(r['contributions'][0])))
 def test_extra_field(self):self.mutate_reject(lambda r:r['contributions'][0].update(guessed_claims='not supplied'))
 def test_unrevealed_is_valid(self):
  d,r=fixture();c=r['contributions'][0];c.update(evidence_level='MECHANISM_UNDISCLOSED',mechanism_type='UNDISCLOSED');c['technical_mechanism']=dict(text=None,evidence_ids=[])
  schema.audit_extraction(r,d)
 def test_title_only_abstention(self):
  d,r=fixture();d['abstract']='';c=r['contributions'][0];c['evidence_spans']=[dict(id='E1',field='title',quote=d['title'])]
  for k in ['technical_problem','technical_mechanism','implementation','expected_effect','applicable_conditions']:c[k]=dict(text=None,evidence_ids=[])
  c.update(structures=[],parameters=[],evidence_level='INSUFFICIENT_EVIDENCE',mechanism_type='UNDISCLOSED')
  schema.audit_extraction(r,d)
 def test_title_only_cannot_claim_mechanism(self):
  d,r=fixture();d['title']=d['abstract'];d['abstract']='';r['contributions'][0]['evidence_spans'][0]['field']='title'
  with self.assertRaises(ValueError):schema.audit_extraction(r,d)
 def test_schema_no_unsupported_keywords(self):schema.check_schema(schema.EXTRACTION_SCHEMA);schema.check_schema(schema.PAIR_SCHEMA)
 def test_wire_evidence_ids_are_program_assigned(self):
  d,r=fixture();out=schema.audit_wire_extraction(to_wire(r),d);self.assertEqual(out['contributions'][0]['evidence_spans'][0]['id'],'E1')
 def test_wire_nonquantitative_parameter_rejected(self):
  d,r=fixture();wire=to_wire(r);wire['contributions'][0]['parameters'][0]['raw']='porous layer'
  with self.assertRaises(ValueError):schema.audit_wire_extraction(wire,d)
 def test_boolean_is_not_integer(self):
  with self.assertRaises(ValueError):schema.validate(True,dict(type='integer'))
class CacheTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(dir=ROOT/'tests');self.w=Path(self.temp.name);(self.w/'state').mkdir();self.oldcommon=common.W;self.oldextract=extract.W;common.W=self.w;extract.W=self.w
  self.conn=common.state_db();self.calls=[]
 def tearDown(self):
  self.conn.close();common.W=self.oldcommon;extract.W=self.oldextract;self.temp.cleanup()
 def fake_request(self,kind,key,messages,sch,attempt,conn):
  self.calls.append(messages);return to_wire(copy.deepcopy(fixture()[1])),'synthetic_unit_test_only'
 def test_cache_and_prompt_change(self):
  d,r=fixture();d['cluster_id']=999
  with patch.object(extract,'request',side_effect=self.fake_request):
   self.assertEqual(extract.do_family(d,'TEST-PROMPT',self.conn),'VALID')
   self.assertEqual(extract.do_family(d,'TEST-PROMPT',self.conn),'CACHED')
   self.assertEqual(len(self.calls),1)
   sent=json.loads(self.calls[0][1]['content']);self.assertEqual(set(sent),{'family_id','title','abstract'})
   self.assertEqual(extract.do_family(d,'TEST-PROMPT-V2',self.conn),'VALID')
   self.assertEqual(len(self.calls),2)
 def test_cache_corruption_detected(self):
  d,r=fixture()
  with patch.object(extract,'request',side_effect=self.fake_request):extract.do_family(d,'TEST-PROMPT',self.conn)
  p=next((self.w/'extractions').glob('*.json'));j=json.loads(p.read_text());j['result']['contributions'][0]['technical_mechanism']['text']='CHANGED';p.write_text(json.dumps(j))
  with self.assertRaises(AssertionError):extract.do_family(d,'TEST-PROMPT',self.conn)
 def test_failed_evidence_never_marked_valid(self):
  d,r=fixture()
  def bad(*a,**kw):
   j=copy.deepcopy(r);j['contributions'][0]['parameters'][0]['raw']='999 nm';return to_wire(j),'synthetic_bad'
  with patch.object(extract,'request',side_effect=bad):self.assertEqual(extract.do_family(d,'TEST-PROMPT',self.conn,max_attempts=2),'FAILED')
  self.assertEqual(self.conn.execute('select status,attempts from extraction').fetchone(),('FAILED_VALIDATION',2))

class RequestAccountingTests(unittest.TestCase):
 setUp=CacheTests.setUp
 tearDown=CacheTests.tearDown
 def test_real_request_path_with_mocked_transport(self):
  d,r=fixture();raw=dict(done=True,done_reason="stop",message=dict(content=json.dumps(r)),prompt_eval_count=10,eval_count=20)
  with patch.object(extract,"api",return_value=raw):
   out,rid=extract.request("extract","synthetic-test",[],schema.EXTRACTION_SCHEMA,1,self.conn)
  self.assertEqual(out["family_id"],d["family_id"])
  self.assertEqual(self.conn.execute("select status,prompt_tokens,output_tokens from requests").fetchone(),("RECEIVED",10,20))
  self.assertTrue((self.w/("responses/"+rid+".raw.json")).exists())
 def test_network_failure_is_recorded_without_tokens(self):
  with patch.object(extract,"api",side_effect=extract.ServiceUnavailable("TEST_ONLY")):
   with self.assertRaises(extract.ServiceUnavailable):extract.request("extract","synthetic-down",[],schema.EXTRACTION_SCHEMA,1,self.conn)
  self.assertEqual(self.conn.execute("select status,prompt_tokens,output_tokens from requests").fetchone(),("NETWORK_FAILED",None,None))

if __name__=='__main__':unittest.main(verbosity=2)
