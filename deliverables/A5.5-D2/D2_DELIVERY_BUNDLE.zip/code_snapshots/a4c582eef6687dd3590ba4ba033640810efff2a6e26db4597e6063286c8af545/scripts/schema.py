"""Strict evaluator for the JSON-Schema keywords used by this project."""
import re,json,unicodedata
from common import object_hash
def s(maxlen=700):return dict(type='string',maxLength=maxlen)
def arr(item,maxn=12,minn=0):return dict(type='array',items=item,minItems=minn,maxItems=maxn)
def obj(props):return dict(type='object',properties=props,required=list(props),additionalProperties=False)
def enum(items):return dict(type='string',enum=items)
facet=obj(dict(text=dict(type=['string','null'],maxLength=700),evidence_ids=arr(s(16),12)))
evidence=obj(dict(id=dict(type='string',pattern='^E[1-9][0-9]*$'),field=enum(['title','abstract']),quote=dict(type='string',minLength=2,maxLength=280)))
list_facet=obj(dict(text=dict(type='string',minLength=1,maxLength=400),evidence_ids=arr(s(16),8,1)))
contribution=obj(dict(
 evidence_spans=arr(evidence,12,1),
 technical_object=facet,technical_problem=facet,technical_mechanism=facet,implementation=facet,expected_effect=facet,applicable_conditions=facet,
 materials=arr(list_facet,8),process_methods=arr(list_facet,8),structures=arr(list_facet,8),
 parameters=arr(obj(dict(name=s(120),kind=enum(['TEMPERATURE','PRESSURE','VOLTAGE','TIME','LENGTH','FREQUENCY','COMPOSITION_RATIO','COUNT','OTHER_QUANTITATIVE']),raw=dict(type='string',minLength=1,maxLength=120,pattern='^.*[0-9０-９].*$'),evidence_ids=arr(s(16),8,1))),8),
 mechanism_type=enum(['STRUCTURE','PROCESS','CONTROL','MATERIAL','CHEMICAL','COMPUTATIONAL','COMPOSITE','UNDISCLOSED']),
 evidence_level=enum(['EXPLICIT_MECHANISM','MECHANISM_UNDISCLOSED','INSUFFICIENT_EVIDENCE']),
 ambiguity_notes=s(1000)))
EXTRACTION_SCHEMA=obj(dict(family_id=dict(type='string',minLength=1),contributions=arr(contribution,4,1)))
EXTRACTION_SCHEMA['$schema']='https://json-schema.org/draft/2020-12/schema'
PAIR_SCHEMA=obj(dict(judgments=arr(obj(dict(left=s(80),right=s(80),relation=enum(['Same','Parent-Child','Alternative','Complementary','Related','Distinct','Uncertain']),parent_id=dict(type=['string','null']),rationale=s(1000),evidence_ids_left=arr(s(16),8),evidence_ids_right=arr(s(16),8))),20,1)))
SUPPORTED={'$schema','type','properties','required','additionalProperties','items','minItems','maxItems','enum','minLength','maxLength','pattern'}
def check_schema(schema):
 assert not set(schema)-SUPPORTED,'Unsupported schema keyword'
 for v in schema.get('properties',{}).values():check_schema(v)
 if 'items' in schema:check_schema(schema['items'])
def validate(value,schema,path='$'):
 typ=schema.get('type');types=typ if isinstance(typ,list) else [typ]
 def ok(t):
  return {'object':isinstance(value,dict),'array':isinstance(value,list),'string':isinstance(value,str),'null':value is None,'boolean':type(value) is bool,'integer':type(value) is int,'number':type(value) in [int,float]}.get(t,False)
 if typ is not None and not any(ok(t) for t in types):raise ValueError(path+': wrong type')
 if 'enum' in schema and value not in schema['enum']:raise ValueError(path+': invalid enum')
 if isinstance(value,dict):
  missing=set(schema.get('required',[]))-set(value)
  if missing:raise ValueError(path+': missing '+','.join(sorted(missing)))
  props=schema.get('properties',{})
  if schema.get('additionalProperties') is False and set(value)-set(props):raise ValueError(path+': extra properties')
  for k,v in value.items():
   if k in props:validate(v,props[k],path+'.'+k)
 if isinstance(value,list):
  if not schema.get('minItems',0)<=len(value)<=schema.get('maxItems',10**9):raise ValueError(path+': array length')
  for i,v in enumerate(value):validate(v,schema['items'],path+f'[{i}]')
 if isinstance(value,str):
  if not schema.get('minLength',0)<=len(value)<=schema.get('maxLength',10**9):raise ValueError(path+': string length')
  if schema.get('pattern') and not re.search(schema['pattern'],value):raise ValueError(path+': pattern')
def numbers(text):
 return set(re.findall(r'(?<![A-Za-z])[-+]?\d+(?:[.,]\d+)*(?:[eE][-+]?\d+)?',unicodedata.normalize('NFKC',text)))
def audit_extraction(result,doc):
 validate(result,EXTRACTION_SCHEMA)
 if result['family_id']!=doc['family_id']:raise ValueError('Family ID mismatch')
 seen=set()
 for i,c in enumerate(result['contributions'],1):
  em={}
  for e in c['evidence_spans']:
   if e['id'] in em:raise ValueError('Duplicate evidence ID')
   text=doc[e['field']] or '';start=text.find(e['quote'])
   if start<0:raise ValueError('Non-verbatim quote '+e['id']+' in '+e['field'])
   em[e['id']]=e;e['start']=start;e['end']=start+len(e['quote'])
  facets=[c[k] for k in ['technical_object','technical_problem','technical_mechanism','implementation','expected_effect','applicable_conditions']]
  facets+=c['materials']+c['process_methods']+c['structures']
  for f in facets:
   ids=f['evidence_ids']
   if any(k not in em for k in ids):raise ValueError('Unknown evidence reference')
   if f['text'] is None:
    if ids:raise ValueError('Null facet cannot claim evidence')
   else:
    if not f['text'].strip() or not ids:raise ValueError('Populated facet needs evidence')
    supported=' '.join(em[k]['quote'] for k in ids)
    if not numbers(f['text'])<=numbers(supported):raise ValueError('UNSUPPORTED_NUMERIC_CITATION: text='+f['text'][:180]+'; uncited_numeric_tokens='+','.join(sorted(numbers(f['text'])-numbers(supported)))+'; include the exact source span containing these tokens, or omit unsupported details')
  for p in c['parameters']:
   if any(k not in em for k in p['evidence_ids']):raise ValueError('Parameter evidence missing')
   if not any(p['raw'] in em[k]['quote'] for k in p['evidence_ids']):raise ValueError('Parameter is not literal source text')
  if c['evidence_level']=='EXPLICIT_MECHANISM' and (not c['technical_mechanism']['text'] or c['mechanism_type']=='UNDISCLOSED'):raise ValueError('Explicit mechanism is missing')
  if c['evidence_level']!='EXPLICIT_MECHANISM' and c['technical_mechanism']['text'] is not None:raise ValueError('Unrevealed mechanism must remain null')
  if not doc.get('abstract') and c['evidence_level']!='INSUFFICIENT_EVIDENCE':raise ValueError('Conservative title-only policy requires abstention')
  key=object_hash([c['technical_mechanism']['text'],c['implementation']['text']])
  if key in seen:raise ValueError('Duplicate contribution within family')
  seen.add(key)
  c['contribution_id']='C_'+object_hash([doc['family_id'],doc['text_hash'],i,c['technical_mechanism']['text'],c['implementation']['text']])[:20]
  c['family_id']=doc['family_id'];c['source_text_hash']=doc['text_hash'];c['effect_interpretation']='disclosed_or_claimed_not_independently_measured'
 return result
check_schema(EXTRACTION_SCHEMA);check_schema(PAIR_SCHEMA)


# Compact model-facing protocol: evidence supports fields, IDs are assigned by code.
CORE_FIELDS=['technical_object','technical_problem','technical_mechanism','implementation','expected_effect','applicable_conditions']
LIST_FIELDS=['materials','process_methods','structures']
WIRE_FIELDS=CORE_FIELDS+LIST_FIELDS+['parameters']
wire_props=dict(evidence_spans=arr(obj(dict(field=enum(['title','abstract']),quote=dict(type='string',minLength=2,maxLength=280),supports=arr(enum(WIRE_FIELDS),10,1))),12,1))
for name in CORE_FIELDS:wire_props[name]=dict(type=['string','null'],maxLength=700)
for name in LIST_FIELDS:wire_props[name]=arr(dict(type='string',minLength=1,maxLength=400),8)
wire_props['parameters']=arr(obj(dict(name=s(120),kind=enum(['TEMPERATURE','PRESSURE','VOLTAGE','TIME','LENGTH','FREQUENCY','COMPOSITION_RATIO','COUNT','OTHER_QUANTITATIVE']),raw=dict(type='string',minLength=1,maxLength=120,pattern='^.*[0-9０-９].*$'))),8)
wire_props['mechanism_type']=contribution['properties']['mechanism_type']
wire_props['evidence_level']=contribution['properties']['evidence_level']
wire_props['ambiguity_notes']=s(1000)
EXTRACTION_WIRE_SCHEMA=obj(dict(family_id=dict(type='string',minLength=1),contributions=arr(obj(wire_props),4,1)))
check_schema(EXTRACTION_WIRE_SCHEMA)
def audit_wire_extraction(wire,doc):
 validate(wire,EXTRACTION_WIRE_SCHEMA)
 result=dict(family_id=wire['family_id'],contributions=[])
 for item in wire['contributions']:
  spans=[];support={name:[] for name in WIRE_FIELDS}
  for j,e in enumerate(item['evidence_spans'],1):
   eid='E'+str(j);spans.append(dict(id=eid,field=e['field'],quote=e['quote']))
   for name in set(e['supports']):support[name].append(eid)
  c=dict(evidence_spans=spans)
  for name in CORE_FIELDS:c[name]=dict(text=item[name],evidence_ids=support[name] if item[name] is not None else [])
  for name in LIST_FIELDS:c[name]=[dict(text=t,evidence_ids=support[name]) for t in item[name]]
  c['parameters']=[dict(**par,evidence_ids=[e['id'] for e in spans if e['id'] in support['parameters'] and par['raw'] in e['quote']]) for par in item['parameters']]
  for name in ['mechanism_type','evidence_level','ambiguity_notes']:c[name]=item[name]
  result['contributions'].append(c)
 return audit_extraction(result,doc)
