"""Material source corrections identified during the 30/100 and fixed source review."""
from common import *
import pandas as pd
def main():
 guard();docs={d['family_id']:d for d in pd.read_parquet(W/'inputs/PATENT_TEXTS.parquet').to_dict('records')};patches={}
 def quote(fid,marker):
  text=docs[fid]['abstract'];pos=text.find(marker);assert pos>=0,(fid,marker)
  start=max(0,pos-35);end=min(len(text),pos+205)
  return dict(field='abstract',start=start,end=end,quote=text[start:end])
 def edit(fid,field,text,markers,reason):
  patch=patches.setdefault(fid,dict(reason=reason,facets={},parameter_kind_fixes=[]))
  patch['reason']=reason;patch['facets'][field]=dict(text=text,quotes=[] if text is None else [quote(fid,m) for m in markers])
 def fix(fid,name,kind,reason):
  patches.setdefault(fid,dict(reason=reason,facets={},parameter_kind_fixes=[]))['parameter_kind_fixes'].append(dict(name=name,kind=kind))
 edit('google:40581936','technical_mechanism','依据具有不同对称性及分极方向的稳定结构X与Y之间的能量差，选择满足 |E(X)−E(Y)|≤E·P·V 的混合钙钛矿组成，其中E·P为电场与自发极化密度的内积，V为基本晶格体积。',['｜Ｅ（Ｘ）','Ｅ・Ｐは'],'模型概述漏掉晶格体积V；按原文恢复判据。')
 edit('google:40581936','applicable_conditions','端元的最稳定晶体结构X、Y具有不同对称性与分极方向；组成及其对应能量须满足原文能量—场耦合判据。',['最も安定な結晶構造Ｘ','｜Ｅ（Ｘ）'],'模型概述漏掉晶格体积V；按原文恢复判据。')
 edit('google:98864925','technical_problem',None,[],'原文直接给出驱动结构及条件，没有模型声称的对称滞回导致输出不足的问题；删去补充解释。')
 edit('google:45993406','technical_mechanism','在衬底上形成平均膜厚至少5μm的(K,A,B)(Nb,C,D)O3类钙钛矿膜，其组成及元素角色受摘要通式(P)和各变量范围限定。',['5μm以上','0&lt;w&lt;1.0'],'将模型误写的严格大于5μm恢复为原文“5μm以上”；完整通式限制仍查源文。')
 edit('google:90417293','technical_mechanism','依次形成多第一电极构成的第一电极层、压电层与含第二电极的第二电极层，并使传感器至少一部分形成曲面以测量曲面分布压力。',['at least part of'],'补回摘要明确的曲面结构限制，避免将普通层叠传感器泛称当特异机制。')
 edit('google:39704160','applicable_conditions','基底主要为Si或SiO2；中间层与第一电极层合计厚度不低于压电层厚度的15%，压电层为铅基材料。',['The thickness of','substrate consisting mainly'],'补回中间层应力方案的厚度比例及材料限定。')
 edit('google:92590282','technical_mechanism','相邻压电膜经含粘接区和间隙区的粘接层层叠；在摘要规定的截面SEM取样条件下，粘接层/压电膜平均厚度比为0.15～1.0，粘接层间隙面积比为1%以上且小于40%。',['接着領域と間隙部','比ｄ'],'SEM是界定结构的观察条件，不是通过观察实施制造控制；改为来源披露的结构限定。')
 edit('google:92590282','implementation',None,[],'SEM是界定结构的观察条件，不是通过观察实施制造控制；改为来源披露的结构限定。')
 edit('google:51658295','technical_mechanism','先用第一蚀刻液图形化20～300nm金属膜，再用第二蚀刻液蚀刻压电膜；压电膜耐第一蚀刻液、金属膜耐第二蚀刻液，以此抑制侧蚀。',['forming a metal film','In the first etchant'],'修正耐蚀性主体：耐受蚀刻液的是对应膜，不是蚀刻液自身。')
 edit('google:51658295','applicable_conditions','第一蚀刻液中压电膜耐蚀；第二蚀刻液中金属硬掩膜耐蚀。',['In the first etchant'],'修正耐蚀性主体：耐受蚀刻液的是对应膜，不是蚀刻液自身。')
 edit('google:73458553','applicable_conditions','撞击位置须使配重在一次外力脉冲下仅撞击悬臂一次，并在下一次外力脉冲到来前不再接触悬臂。',['錘が衝突する部位'],'补回单脉冲单次撞击这一位置选择约束。')
 edit('google:34467468','implementation','经金属氧化物粘附层在支撑板形成导电下电极，再喷射沉积介电材料粉末并热处理；上电极可在热处理之前或之后形成。',['The manufacturing method comprises','before or after'],'模型仅保留层结构，补回摘要中独立披露的制造步骤；仍保留综合贡献，是否拆分待人审。')
 edit('google:87762874','applicable_conditions','两压电膜的自发极化沿相同厚度方向；按摘要分别定义的矫顽电压量，必须同时满足 ΔVcr < ΔVcf - 0.2 和 Vcr < Vcf - 0.2。',['directions of the spontaneous polarizations are the same','are satisfied'],'补回不能因传输失败当作不存在的两项矫顽电压限制；符号释义以原文为准。')
 edit('google:36033435','technical_mechanism','在压电体所定方向电场的低电位侧设置金属氧化物层以补偿该电场产生的氧空位；高电位侧另设金属氧化物层，以补偿反向电场造成的累积氧空位。',['金属酸化物層１６６','金属酸化物層１６４'],'细化两侧金属氧化物层分别对应正反方向电场的作用，防止泛化为任意氧化物覆盖。')
 fix('google:81000018','inclination','OTHER_QUANTITATIVE','原文角度1°的物理量类型不是计数。')
 fix('google:42630618','Piezoelectric constant d31','OTHER_QUANTITATIVE','压电系数不是组成比；原始值及单位保留。')
 fix('google:85602693','導熱率','OTHER_QUANTITATIVE','导热率不是时间；原始值及单位保留。')
 patches['google:92590282']['mechanism_type']='STRUCTURE'
 patches['google:98864925']['drop_parameter_names']=['最小電圧値','0[V]での傾き','最小電圧値V1での傾き']
 save('evidence/ASSISTANT_SOURCE_AMENDMENTS.json',dict(version='assistant-source-amendment-v1',reviewer='AI assistant, not human Gold',raw_model_outputs_unchanged=True,families=patches))
 print(stable(dict(amended_families=len(patches))))
if __name__=='__main__':main()
