"""Incremental family-keyed extraction. Real requests only, honest retry/failure accounting."""
from common import *
from schema import EXTRACTION_SCHEMA,EXTRACTION_WIRE_SCHEMA,audit_wire_extraction
import urllib.request,urllib.error,argparse,fcntl,traceback
MODEL='qwen3-coder:30b'
DIGEST='06c1097efce0431c2045fe7b2e5108366e43bee1b4603a7aded8f21689e90bca'
SERVER='http://192.168.0.21:11434'
CODE_VERSION='UNIT_TEST_ONLY'
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**kw):raise RuntimeError('Redirect forbidden')
OPENER=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
class ServiceUnavailable(RuntimeError):pass
class APIProtocolError(RuntimeError):pass
def api(path,payload=None,timeout=600):
 assert path in ['/api/tags','/api/version','/api/ps','/api/chat','/api/embed']
 data=None if payload is None else json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()
 req=urllib.request.Request(SERVER+path,data=data,headers={'Content-Type':'application/json'})
 try:
  with OPENER.open(req,timeout=timeout) as r:return json.load(r)
 except urllib.error.HTTPError as e:
  detail=e.read(4000).decode('utf-8','replace');raise APIProtocolError('HTTP '+str(e.code)+': '+detail) from e
 except (urllib.error.URLError,TimeoutError,ConnectionError,OSError) as e:raise ServiceUnavailable(str(e)) from e
def freeze_code():
 global CODE_VERSION
 import shutil
 files=list((W/'scripts').glob('*.py'))+list((W/'tests').glob('*.py'))+list((W/'prompts').glob('*.txt'))
 hashes={str(p.relative_to(W)):sha(p) for p in files}
 CODE_VERSION=object_hash(hashes)
 dest=W/'code_snapshots'/CODE_VERSION
 if not dest.exists():
  for p in files:
   out=dest/p.relative_to(W);out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)
  save('code_snapshots/'+CODE_VERSION+'/manifest.json',dict(created_at=now(),sha256=hashes))
 return CODE_VERSION
def preflight():
 tags=api('/api/tags',timeout=10);found=[m for m in tags.get('models',[]) if m.get('name')==MODEL]
 assert len(found)==1 and found[0]['digest']==DIGEST,'Model missing or changed: no substitution'
 rec=dict(at=now(),server=SERVER,model=found[0],version=api('/api/version',timeout=10),options=dict(temperature=0,seed=42,num_ctx=12288,num_predict=2200),concurrency=1)
 save('evidence/MODEL_LOCK.json',rec);return rec
def request(kind,key,messages,schema,attempt,conn):
 payload=dict(model=MODEL,messages=messages,stream=False,format=schema,options=dict(temperature=0,seed=42,num_ctx=12288,num_predict=min(6000,2200+1600*(attempt-1))),keep_alive='10m')
 rid=kind+'_'+object_hash([key,attempt])[:24];start=now();t=time.monotonic()
 save('requests/'+rid+'.input.json',dict(request_id=rid,cache_key=key,payload=payload,server=SERVER,code_version=CODE_VERSION))
 conn.execute('insert or replace into requests values(?,?,?,?,?,?,?,?,?,?)',(rid,kind,key,start,None,'RUNNING',None,None,None,None));conn.commit()
 try:
  raw=api('/api/chat',payload);wall=time.monotonic()-t
 except Exception as e:
  conn.execute('update requests set finished_at=?,status=?,wall_s=?,error=? where request_id=?',(now(),'API_REJECTED' if isinstance(e,APIProtocolError) else 'NETWORK_FAILED',time.monotonic()-t,str(e),rid));conn.commit();raise
 save('responses/'+rid+'.raw.json',raw)
 conn.execute('update requests set finished_at=?,status=?,prompt_tokens=?,output_tokens=?,wall_s=? where request_id=?',(now(),'RECEIVED',raw.get('prompt_eval_count'),raw.get('eval_count'),wall,rid));conn.commit()
 if not raw.get('done') or raw.get('done_reason')=='length':raise ValueError('Truncated generation')
 return json.loads(raw['message']['content']),rid
def key_for(doc,prompt):
 return object_hash(dict(family_id=doc['family_id'],text_hash=doc['text_hash'],input_payload=dict(title=doc['title'],abstract=doc['abstract']),schema=EXTRACTION_SCHEMA,wire_schema_json=json.dumps(EXTRACTION_WIRE_SCHEMA,ensure_ascii=False),prompt=prompt,model=MODEL,digest=DIGEST,version='D2-contribution-evidence-v3'))
def do_family(doc,prompt,conn,max_attempts=3):
 fid=doc['family_id'];key=key_for(doc,prompt)
 existing=conn.execute('select cache_key,status,result_path,attempts,error from extraction where family_id=?',(fid,)).fetchone()
 if existing and existing[0]==key and existing[1]=='VALID':
  saved=load(existing[2]);assert saved['cache_key']==key and saved['result']['family_id']==fid
  assert saved['source_text_hash']==doc['text_hash'] and saved['result_sha256']==object_hash(saved['result']),'Cached result changed'
  return 'CACHED'
 errors=[existing[4]] if existing and existing[0]==key and existing[1]=='FAILED_VALIDATION' and existing[4] else [];start_attempt=existing[3] if existing and existing[0]==key else 0
 # Each resumed run retries only unresolved families, bounded to three attempts in that run.
 for offset in range(max_attempts):
  guard();attempt=start_attempt+offset+1
  body=dict(family_id=fid,title=doc['title'],abstract=doc['abstract'])
  assert set(body)=={'family_id','title','abstract'}
  messages=[dict(role='system',content=prompt),dict(role='user',content=stable(body))]
  if errors:messages.append(dict(role='user',content='前次结果未通过校验。只根据原输入修正，缺少依据时弃判。错误：'+errors[-1][:900]))
  try:
   result,rid=request('extract',key,messages,EXTRACTION_WIRE_SCHEMA,attempt,conn)
   result=audit_wire_extraction(result,doc)
   path='extractions/'+fid.replace(':','_')+'.json'
   save(path,dict(cache_key=key,model=MODEL,model_digest=DIGEST,prompt_sha256=digest_bytes(prompt.encode()),schema_sha256=object_hash(EXTRACTION_SCHEMA),wire_schema_sha256=object_hash(EXTRACTION_WIRE_SCHEMA),source_text_hash=doc['text_hash'],request_id=rid,validated_at=now(),code_version=CODE_VERSION,result_sha256=object_hash(result),result=result))
   conn.execute('insert or replace into extraction values(?,?,?,?,?,?,?)',(fid,key,'VALID',path,attempt,now(),None));conn.commit()
   event('family_valid',family_id=fid,attempt=attempt,contributions=len(result['contributions']));return 'VALID'
  except ServiceUnavailable as e:
   conn.execute('insert or replace into extraction values(?,?,?,?,?,?,?)',(fid,key,'RETRYABLE_NETWORK',None,attempt,now(),str(e)));conn.commit();raise
  except (ValueError,KeyError,TypeError,AssertionError) as e:
   errors.append(str(e));save('failures/'+key+f'.attempt{attempt}.json',dict(family_id=fid,error=str(e),attempt=attempt,at=now()))
   conn.execute('update requests set status=?,error=? where kind=? and cache_key=? and request_id=?',('VALIDATION_FAILED',str(e),'extract',key,'extract_'+object_hash([key,attempt])[:24]));conn.commit()
   event('family_validation_retry',family_id=fid,attempt=attempt,error=str(e))
 conn.execute('insert or replace into extraction values(?,?,?,?,?,?,?)',(fid,key,'FAILED_VALIDATION',None,start_attempt+max_attempts,now(),errors[-1]));conn.commit();return 'FAILED'
def stage_summary(name,ids,conn,docs,prompt):
 rows={r[0]:r for r in conn.execute('select family_id,status,attempts,cache_key from extraction')}
 statuses={}
 for fid in ids:
  row=rows.get(fid)
  status='UNATTEMPTED' if row is None else (row[1] if row[3]==key_for(docs[fid],prompt) else 'STALE_DIFFERENT_PROTOCOL')
  statuses[status]=statuses.get(status,0)+1
 rec=dict(at=now(),stage=name,required_families=len(ids),statuses=statuses,complete=sum(v for k,v in statuses.items() if k in ['VALID','FAILED_VALIDATION'])==len(ids),valid=statuses.get('VALID',0),failed=statuses.get('FAILED_VALIDATION',0))
 save('evidence/STAGE_'+name+'.json',rec);return rec
def main():
 p=argparse.ArgumentParser();p.add_argument('--stage',choices=['pilot30','trial100','primary384','all_selected','sequence'],default='pilot30');p.add_argument('--preflight-only',action='store_true');p.add_argument('--limit',type=int);args=p.parse_args()
 guard();freeze_code()
 lock=(W/'state/worker.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 conn=state_db()
 for name,h in load('inputs/DATASET_FROZEN.json')['sha256'].items():assert sha(W/name)==h,name
 try:preflight()
 except ServiceUnavailable as e:
  save('evidence/SERVICE_UNAVAILABLE.json',dict(at=now(),server=SERVER,status='UNAVAILABLE',error=str(e),actual_inference_requests=conn.execute("select count(*) from requests where kind='extract'").fetchone()[0]))
  event('service_unavailable',server=SERVER,error=str(e));return 3
 if args.preflight_only:event('preflight_passed',model=MODEL,digest=DIGEST);return 0
 import pandas as pd
 docs={r['family_id']:r for r in pd.read_parquet(W/'inputs/PATENT_TEXTS.parquet').to_dict('records')};stages=load('inputs/STAGES.json');prompt=(W/'prompts/extraction_v2.txt').read_text()
 names=['pilot30','trial100','primary384','all_selected'] if args.stage=='sequence' else [args.stage]
 for name in names:
  ids=stages[name]
  for fid in (ids[:args.limit] if args.limit is not None else ids):
   try:do_family(docs[fid],prompt,conn)
   except ServiceUnavailable as e:
    stage_summary(name,ids,conn,docs,prompt);event('stage_paused_network',stage=name,error=str(e));return 3
  summary=stage_summary(name,ids,conn,docs,prompt);event('stage_finished',**summary)
  if name in ['pilot30','trial100']:
   event('quality_review_required',stage=name,message='Review actual source/evidence and failures before expanding.')
   if args.stage=='sequence':return 4
 return 0
if __name__=='__main__':sys.exit(main())
