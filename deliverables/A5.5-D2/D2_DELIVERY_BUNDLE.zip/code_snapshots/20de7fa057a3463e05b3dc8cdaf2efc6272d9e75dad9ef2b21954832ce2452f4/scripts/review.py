"""Build editable review records; AI review is separate from human annotations."""
from common import *
from consolidate import current_records
import pandas as pd,argparse
CRITERIA=['object_accuracy','problem_source_support','mechanism_source_support','multi_contribution_completeness','parameter_fidelity','over_split_check','over_merge_check']
def prepare(stage='all_selected'):
 guard();rows,status,objects=current_records(stage);byfamily={}
 for c in objects:byfamily.setdefault(c['family_id'],[]).append(c)
 selection=load('inputs/AUDIT_SELECTION.json')['family_ids'];notes=load('evidence/AUDIT80_SOURCE_READING.json')['family_notes']
 ratings=load('evidence/ASSISTANT_AUDIT80_RATINGS.json')['rows'] if (W/'evidence/ASSISTANT_AUDIT80_RATINGS.json').exists() else []
 ratings={x['family_id']:x for x in ratings}
 auxiliary={}
 for filename in ['evidence/PILOT30_SOURCE_AUDIT.json','evidence/TRIAL100_SOURCE_AUDIT.json']:
  if (W/filename).exists():
   for r in load(filename).get('rows',[]):
    auxiliary[r['family_id']]=dict(decision='AI_PILOT_SOURCE_REVIEW',notes=r.get('note') or r.get('notes'))
 ids=set(selection)|{s['family_id'] for s in status if s['status']=='FAILED_VALIDATION'}
 # All technical facet gaps are reviewable, but do not change the fixed audit denominator.
 for c in objects:
  if c['field_evidence_gaps'] or c.get('rejected_parameter_claims'):ids.add(c['family_id'])
 docs={r['family_id']:r for r in pd.read_parquet(W/'inputs/PATENT_TEXTS.parquet').to_dict('records')}
 st={x['family_id']:x for x in status};out=[]
 for fid in sorted(ids):
  d=docs[fid];cs=byfamily.get(fid,[]);rating=ratings.get(fid,auxiliary.get(fid,{}))
  row=dict(family_id=fid,fixed_audit80=fid in selection,processing_status=st.get(fid,{}).get('status','UNATTEMPTED'),processing_error=st.get(fid,{}).get('error'),source_title=d['title'],source_abstract=d['abstract'],contribution_ids_json=stable([c['contribution_id'] for c in cs]),extracted_mechanisms='\n'.join(c['technical_mechanism']['text'] or '[ABSTAIN]' for c in cs),source_first_AI_note=notes.get(fid),assistant_review_status=rating.get('decision','SOURCE_READ_OUTPUT_COMPARISON_PENDING' if fid in selection else 'NOT_AUDITED'),assistant_review_notes=rating.get('notes'),human_status='待人工',human_reviewer=None,human_edit=None,human_notes=None,field_evidence_gaps_json=stable({c['contribution_id']:c['field_evidence_gaps'] for c in cs}),rejected_parameter_claims_json=stable({c['contribution_id']:c.get('rejected_parameter_claims',[]) for c in cs}),not_human_gold=True)
  for criterion in CRITERIA:row['human_'+criterion]=None
  out.append(row)
 pd.DataFrame(out).to_parquet(W/'outputs/REVIEW_QUEUE.parquet',index=False)
 save('evidence/AUDIT80_PROGRESS.json',dict(at=now(),fixed_families=80,source_read=80,output_comparisons_completed=len(ratings),human_gold_labels=0,editable_review_rows=len(out),semantic_accuracy_estimate=None,reason='No independent human gold set; assistant source reviews are qualitative diagnostics'))
 return out
def cards(stage,start,stop):
 _,status,objects=current_records(stage);ids=load('inputs/AUDIT_SELECTION.json')['family_ids'][start:stop]
 selected=[c for c in objects if c['family_id'] in ids];notes=load('evidence/AUDIT80_SOURCE_READING.json')['family_notes']
 for fid in ids:
  cs=[c for c in selected if c['family_id']==fid]
  print(stable(dict(family_id=fid,source_note=notes[fid],processing_status=next((s['status'] for s in status if s['family_id']==fid),'UNATTEMPTED'),contributions=[{k:c.get(k) for k in ['contribution_id','technical_object','technical_problem','technical_mechanism','implementation','expected_effect','applicable_conditions','parameters','evidence_level','ambiguity_notes']} for c in cs])))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--stage',default='all_selected');p.add_argument('--cards',action='store_true');p.add_argument('--start',type=int,default=0);p.add_argument('--stop',type=int,default=10);a=p.parse_args()
 if a.cards:cards(a.stage,a.start,a.stop)
 else:prepare(a.stage)
