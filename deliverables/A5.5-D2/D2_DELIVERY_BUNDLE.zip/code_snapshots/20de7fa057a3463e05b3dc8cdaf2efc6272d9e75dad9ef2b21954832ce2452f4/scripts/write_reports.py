"""Factual D2 reports, generated only after frozen and post-hoc data exist."""
from common import *
from posthoc_relevance import verify_freeze
import pandas as pd,collections,statistics
def md(x):return str(x if x is not None else 'n.a.').replace('|',' / ').replace('\n',' ')
def table(h,rows):return '\n'.join(['| '+' | '.join(h)+' |','|'+'|'.join(['---']*len(h))+'|']+['| '+' | '.join(md(v) for v in r)+' |' for r in rows])
def write(n,s):(W/'outputs'/n).write_text(s.strip()+'\n')
def union_seconds(rows):
 spans=sorted((datetime.datetime.fromisoformat(r['started_at']).timestamp(),datetime.datetime.fromisoformat(r['finished_at']).timestamp()) for r in rows if r['finished_at'])
 total=0;start=end=None
 for a,b in spans:
  if start is None:start,end=a,b
  elif a<=end:end=max(end,b)
  else:total+=end-start;start,end=a,b
 return total+(end-start if start is not None else 0)
def main():
 guard();freeze=verify_freeze();kb=load('working/all_selected/KB_RECORDS.json');cs=load('working/all_selected/contributions.json');cases=load('outputs/REAL_TECHNOLOGY_CASES.json')['cases']
 hist=load('outputs/HISTORICAL_VALIDATION.json');assert hist['completed']==45
 rel=load('outputs/PRINTHEAD_RELEVANCE.json');assert rel['completed']==rel['required']
 comp=load('outputs/D1_D2_COMPARISON.json')
 audit=load('evidence/ASSISTANT_AUDIT80_RATINGS.json');assert len(audit['rows'])==80
 concepts={t['technology_id']:t for t in kb['concepts']};ct={r['contribution_id']:r['technology_id'] for r in kb['patent_technology']}
 members=pd.read_parquet(W/'inputs/CLUSTER_MEMBERS.parquet');cohorts=pd.read_csv(W/'inputs/COHORTS.csv')
 conn=state_db();conn.row_factory=sqlite3.Row;req=[dict(r) for r in conn.execute('select * from requests order by started_at')];conn.close()
 from performance_metrics import compute as performance_compute
 performance=performance_compute(req,union_seconds)
 cost=[]
 for kind in sorted({r['kind'] for r in req}):
  rr=[r for r in req if r['kind']==kind];p=[r['prompt_tokens'] for r in rr if r['prompt_tokens'] is not None];o=[r['output_tokens'] for r in rr if r['output_tokens'] is not None]
  cost.append(dict(kind=kind,requests=len(rr),receipts=len(p),input_tokens=sum(p),output_tokens=sum(o),mean_input=statistics.mean(p) if p else None,mean_output=statistics.mean(o) if o else None,original_contract_failures=sum(r['status']=='VALIDATION_FAILED' for r in rr),api_rejections=sum(r['status']=='API_REJECTED' for r in rr),network_failures=sum(r['status']=='NETWORK_FAILED' for r in rr),summed_request_wall_s=sum(r['wall_s'] or 0 for r in rr),interval_union_s=union_seconds(rr)))
 cost_md=table(['请求类型','请求数','输入token','输出token','均输入','均输出','原契约失败','API拒绝','网络失败','区间并集小时'],[[r['kind'],r['requests'],r['input_tokens'],r['output_tokens'],round(r['mean_input'] or 0,1),round(r['mean_output'] or 0,1),r['original_contract_failures'],r['api_rejections'],r['network_failures'],round(r['interval_union_s']/3600,3)] for r in cost])
 syntax={}
 for r in req:
  p=W/'responses'/(r['request_id']+'.raw.json')
  if r['kind']=='embed' or not p.exists():continue
  raw=load(str(p));v=syntax.setdefault(r['kind'],dict(responses=0,json_parse_failures=0,truncated=0));v['responses']+=1;v['truncated']+=raw.get('done_reason')=='length'
  try:json.loads(raw['message']['content'])
  except (ValueError,KeyError,TypeError):v['json_parse_failures']+=1
 status={r['family_id']:r['status'] for r in kb['processing_status']};explicit={c['family_id'] for c in cs if c['evidence_level']=='EXPLICIT_MECHANISM'}
 primary=set(load('inputs/STAGES.json')['primary384']);pcs=[c for c in cs if c['family_id'] in primary];pt={ct[c['contribution_id']] for c in pcs if c['contribution_id'] in ct}
 bn=[t for t in concepts.values() if t['level']=='B'];an=[t for t in concepts.values() if t['level']=='A'];domains={concepts[t]['parent_technology_id'] for t in pt}
 cohort_rows=[]
 for co in cohorts.to_dict('records'):
  ids=set(members[members.selection_id==co['selection_id']].family_id);cc=[c for c in cs if c['family_id'] in ids];tt={ct[c['contribution_id']] for c in cc if c['contribution_id'] in ct}
  cohort_rows.append([co['selection_id'],int(co['population_size']),len(ids),sum(status[f]=='FAILED_VALIDATION' for f in ids),len(ids&explicit),len(cc),len(tt),'全群' if co['complete_cluster'] else '抽样'])
 cohort_md=table(['选择','群总体','抽取族','失败族','明确手段标签族','贡献','候选机制','覆盖'],cohort_rows)
 hc=[]
 for group in ['Recipe','Equipment']:
  for outcome in ['Mechanism Recovered','Broad Topic Only','Mechanism Missed','Insufficient Source Evidence']:
   rr=[r for r in hist['rows'] if r['history_group']==group and r['outcome']==outcome]
   hc.append([group,outcome,len(rr),sum(r['discovery_scope']=='CORE_DISCOVERY_COHORT' for r in rr)])
 hist_md=table(['历史组','恢复结果','族数','冻结发现范围内'],hc)
 cross=[]
 for t in bn:
  mm=[m for m in kb['cluster_technology'] if m['technology_id']==t['technology_id']]
  if t['family_count']<2 or t['distinct_source_text_count']<2 or len(mm)<2:continue
  byrun={}
  for m in mm:byrun.setdefault(m['run_id'],set()).add(m['cluster_id'])
  cross.append(dict(technology_id=t['technology_id'],name=t['name'],families=t['family_count'],multiple_clusters_in_same_run=any(len(s)>1 for s in byrun.values()),support_family_ids=json.loads(t['support_family_ids_json']),support_cids=json.loads(t['support_contribution_ids_json'])))
 save('outputs/CROSS_CLUSTER_MECHANISM_EVIDENCE.json',dict(rows=cross,rule='At least two Family IDs and two distinct source title/abstract texts; identical source clones and repeated placement of one family are excluded',scope='Selected cohorts only'))
 spans=sum(len(c['evidence_spans']) for c in cs);gaps=sum(bool(c['field_evidence_gaps']) for c in cs);rejected=sum(len(c.get('rejected_parameter_claims',[])) for c in cs);curated=sum(bool(c.get('curation_provenance_json')) for c in cs);refined=sum(bool(c.get('refinement_provenance_json')) for c in cs)
 case_text=[]
 for i,c in enumerate(cases,1):
  case_text.append(f"### {i}. {c['name']}\n\n{c['technology_id']} · {c['family_id']} · {c['domain']}\n\n原文（{c['source_field']}）：\n\n> "+c['evidence_short'].replace('\n','\n> ')+"\n\n喷头关联："+c['relevance']+"；证据性质："+c['evidence_origin']+"。")
 report="# A5.5-D2 真实技术发现\n\n"+"\n\n".join(case_text)
 report+=f"""

## 范围

冻结1117个唯一族、1688条选定群来源关系，原238,541族向量与聚类只读复用。未重编码、未重聚类。本轮不是全库穷尽知识库。以下机制数量均为当前候选，不是人类真值。

{cohort_md}

## 十个问题

1. **主群有多少机制？** 384族全部尝试，{len(primary&explicit)}族有明确手段标签，{len(pcs)}条贡献归并为{len(pt)}个候选机制节点。缺少独立人审与穷尽比较，不能把候选数当真实不同机制总数。
2. **哪些具体技术可识别？** 首页20例均可回到族、原字段、逐字原文。晶种定向生长、氧空位补偿、粉体撞击沉积、互耐蚀硬掩膜及非目标领域案例展示了来源支持的具体办法。来源支持范围是摘要披露，不是Claims或实际采用。
3. **群内路线是否不同？** 是。结构、材料组成、加工和驱动办法并存；主群候选分入{len(domains)}个开放对象/问题域。域标签仍需人审整合，不能仅靠域数量判断质量。
4. **是否跨群复用？** {len(cross)}个候选节点由至少两个独立族支持且关联多个选定群，其中{sum(r['multiple_clusters_in_same_run'] for r in cross)}个跨同一run不同群。CID、Family和理由见CROSS_CLUSTER_MECHANISM_EVIDENCE.json与关系表；单族在多模型重复出现不作为技术一致证明。
5. **是否明显优于统一命名？** 新架构可表达多贡献、具体机制与双向证据；统一名称不足以承载这些关系。但覆盖、调用成本与助手修订不同，未建立同成本的独立人类Gold对照，不能宣称语义准确率显著提高。
6. **设备、工艺、材料可否区分？** 可在贡献层区分结构、过程、控制、材料/化学、计算及复合办法。压差隔壁、先蚀硬掩膜再蚀压电膜、组成/晶相限定提供真实来源例子；不从Cluster ID推导类别。
7. **信息不足如何避免伪造？** 仅标题确定性弃判，保留标题并记录零模型调用。外观声明无附图、缺公式或未披露手段的摘要保留不足/未披露/不确定。符号定义不当作数值参数；不合契约的模型值留在拒收审计而不进入事实参数。失败不等于无技术价值。
8. **历史45族恢复如何？** 以下为冻结后的AI源文回归，不是独立人工真值。范围外探针另列；历史标签不补写摘要，历史回归不推出未知技术全库Recall。

{hist_md}

9. **随机及非目标群有效吗？** 两个随机中群、混合抽样、紧密小群和Noise均纳入。真实出现蛋白稳定性建模、CO2饱和pH膜、扫描单元吸附增重避振等办法。部分紧密群只有标题或外观模板；语义紧密不保证摘要可抽机制。各组真实分母见上表。
10. **能否扩展238,541族？** 缓存、稳定ID、近邻候选与有限关系比较已构成增量原型，本轮未执行全库抽取。当前质量尚不适合无人复核的全库生产。主要成本是逐族生成、关系比较、命名和源文复核；瓶颈是关键限定、参数/单位、公式和多贡献拆分。应分片逐批扩大并保留人审；本轮偏向目标领域的吞吐与质量不能直接作为全库保证。

## 实际调用

{cost_md}

以上仅统计LAN Ollama回执，不含Codex对话token。调试、失败、二次抽取全部记账。并发请求耗时之和包含排队和重叠，不是GPU计算小时；区间并集也包含网络服务等待。缺失token不伪造。HTTP拒绝不当已生成内容。原始在线契约失败、JSON语法失败与离线重放通过分别记录。

实际吞吐与运行耗时另见 PERFORMANCE_METRICS.json：包含显式阶段时间、模型请求区间并集、项目首末请求墙钟时间和有条件的全库抽取外推。队列等待及开发/断网间隔不当成GPU计算时间。

## 可追溯性与限制

五类核心逻辑表在SQLite和Parquet中按ID联查；Excel提供阅读与人工修订。完整Title/Abstract保留，{spans}个证据片段逐个核对字符坐标。{gaps}条贡献仍有字段标记缺口；{curated}条含助手原文修订，{refined}条采用二次抽取，{rejected}个参数提议未进入事实参数表。原始响应未改写。程序VALID不是语义准确，助手复核不是人类Gold。
核心定义先冻结，之后才开展喷头相关性、历史核验和D1对照。Transferable是有条件工程推断，不表示实际采用。混合群与Noise只覆盖抽样成员。
"""
 write('D2_REPORT.md',report)
 errors="""## 已证实的错误与边界

- 初期将明确结构/工艺错误弃判；保留全部校准成本。
- HTML/长公式反复抄写造成改写、重复与截断；改为片段ID后由程序复制原句，但引用相关性仍需语义审计。
- 40581936漏晶格体积V；角度被标COUNT、压电系数被标组成比、导热率被标TIME，已保留原始记录及源文修订。
- 首批将Ca含量范围与厚度方向Ca梯度仅因共同材料判Same，源文复核后保留Related；原始判断与修订均保留。不同Family ID的完全相同摘要属于重复文本证据，不能当独立跨群发现。
- 变量V1、T0和图号不等于定量值；需核对物理量与单位，不能仅查数字。
- SEM/XPS观察条件不可冒充制造步骤；材料表征限定不可自动写成制程。
- 97217328的柱径差≤10%与97218156的>10%不可因结构相似强并。
- 初始384族全部单贡献；49512008经source-only复核接受两项拆分，58557302二次输出改写关系被拒收。没有独立量化多贡献Recall。
- 全半角、Unicode负号、日文割/百分数和千分符存在确定性表示等价；源文引句始终逐字保存，单位仍须核查。
- 无图外观声明不能补几何形状，缺失公式不能凭历史或专利号补全。

"""
 quality=f"# 抽取质量\n\n范围1117族，状态{dict(collections.Counter(status.values()))}，贡献{len(cs)}条，明确手段标签族{len(explicit)}个。逐字/坐标通过{spans}条，只代表结构与复制完整性。\n\n固定80族有源文预读与逐族AI对照记录；人审栏留空，没有独立Gold，不提供全样本语义准确率。\n\n"+errors+f"当前{gaps}条贡献有字段证据缺口，{rejected}个参数提议被留在拒收记录，{curated}条含助手修订。不能用修订后结果冒充原始模型准确率。\n\n## 归并边界\n\n向量只提候选，Same由双侧源文LLM判断，并另作一次保守源文复核；两轮同意才可支持归并。两轮均是同一本地模型，不是独立人类Gold。小组要求全对Same，大组双锚点加冲突否决。未比较不当Uncertain。对象/问题域组织与机制范围继承分开，循环继承暂缓；关系均是可追溯候选。有限近邻不能保证找齐同义技术。\n\n## 成本\n\n"+cost_md+"\n\nJSON语法统计："+stable(syntax)
 write('EXTRACTION_QUALITY.md',quality)
 write('HISTORICAL_TECHNOLOGY_VALIDATION.md','# 历史技术事后回归\n\n核心冻结：'+freeze['at']+'。历史名称未用于抽取、归并、命名或层级。以下为AI源文核验，待人审；范围外补充探针不得冒充首次发现。\n\n'+hist_md+'\n\n'+table(['Family ID','组','覆盖','结果','理由'],[[r['family_id'],r['history_group'],r['discovery_scope'],r['outcome'],r['reason']] for r in hist['rows']])+'\n\n历史只是已知路线回归，不能推出全库未知技术Recall。')
 write('EXPERIMENT_COMPARISON.md','# D1统一命名与D2逐族抽取\n\n'+comp['method_notes']+'\n\n'+table(comp['headers'],comp['rows'])+f'\n\nD2共{len(cs)}条贡献、{len(bn)}候选机制，{gaps}条字段引用缺口。更多、更细名称不自动表示更准确。原文覆盖、成本、修订和审核条件不同，没有独立人类Gold下的同成本准确率对照。\n\n'+cost_md)
 files=lambda folder,pattern:{str(p.relative_to(W)):sha(p) for p in sorted((W/folder).glob(pattern)) if p.is_file()}
 save('outputs/PERFORMANCE_METRICS.json',performance)
 save('outputs/EXPERIMENT_MANIFEST.json',dict(performance=performance,at=now(),task='A5.5-D2',scope_families=1117,selected_memberships=1688,core_freeze=freeze,request_summary=cost,json_syntax_stats=syntax,request_status_counts=dict(collections.Counter(r['status'] for r in req)),source_locks=load('inputs/SOURCE_LOCKS.json'),dataset_freeze=load('inputs/DATASET_FROZEN.json'),selection_rules=load('inputs/SELECTION_RULES.json'),audit_selection=load('inputs/AUDIT_SELECTION.json'),model_lock=load('evidence/MODEL_LOCK.json'),embedding_lock=load('vectors/MODEL_LOCK.json'),code_sha256=files('scripts','*'),prompt_sha256=files('prompts','*'),schema_sha256=files('configs','*.json'),actual_generation_options_and_code='Per-request inputs/raw receipts plus code_snapshots',human_gold_families=0,semantic_accuracy_estimate=None,raw_patents_reencoded=0,reclustering_runs=0,github_publication_performed=False))
 print(stable(dict(reports_written=4,manifest_written=True,requests=len(req))))
if __name__=='__main__':main()
